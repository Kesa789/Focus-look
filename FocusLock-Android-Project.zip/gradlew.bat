@rem FocusLock Gradle wrapper script for Windows
@rem Execute gradle build
gradle %*
