# FocusLock - Native Android Focus Blocker

A production-grade, native Android focus session blocker built in **Kotlin** and **Jetpack Compose** with **Material 3**, inspired by Blockit. FocusLock uses an Android **AccessibilityService** combined with an atomic timestamp persistence architecture (Room + DataStore/SharedPreferences) to strictly enforce an application whitelist ("Suitcase") during active deep-work sessions.

---

## Architecture Overview

```
                      ┌───────────────────────────────────────┐
                      │              MainActivity             │
                      │    (Jetpack Compose UI Navigation)    │
                      └──────────────────┬────────────────────┘
                                         │
                         ┌───────────────┴───────────────┐
                         ▼                               ▼
              ┌─────────────────────┐         ┌─────────────────────┐
              │    FocusViewModel   │         │   AppsRepository    │
              │  (Session Ticker &  │         │ (Launcher Discovery │
              │   Room Live Data)   │         │  & Whitelist Mgmt)  │
              └──────────┬──────────┘         └──────────┬──────────┘
                         │                               │
       ┌─────────────────┼───────────────────────────────┤
       ▼                 ▼                               ▼
┌──────────────┐ ┌──────────────┐             ┌─────────────────────┐
│ FocusDatabase│ │ Preferences  │◄────────────┤ FocusAccessibility  │
│  (Room DAO   │ │   Manager    │  (Fast      │       Service       │
│  Persistence)│ │ (Atomic Sync)│   Lookups)  │ (Window Interceptor)│
└──────────────┘ └───────┬──────┘             └──────────┬──────────┘
                         │                               │ Launches
                         │                               ▼
                         │                    ┌─────────────────────┐
                         │                    │   BlockingActivity  │
                         │                    │ (Fullscreen Overlay)│
                         │                    └─────────────────────┘
                         ▼
              ┌─────────────────────┐
              │  FocusForeground    │
              │       Service       │
              │ (Watchdog & Notif)  │
              └─────────────────────┘
```

---

## Key Technical Features

1. **AccessibilityService App Whitelist Enforcer (`FocusAccessibilityService`)**
   - Intercepts `TYPE_WINDOW_STATE_CHANGED` events with 50ms polling timeout.
   - Fast $O(1)$ memory/shared-preferences lookup of whitelisted packages to avoid blocking the main thread.
   - Built-in debounce/rate-limiting (800ms per target package) to prevent uncontrolled activity launch loops.
   - Safe exclusions for:
     - FocusLock app itself
     - Android System UI (`com.android.systemui`)
     - Default Home / Launcher (`android.intent.category.HOME`)
     - Android Input Method Editors (on-screen keyboards)
     - Permission dialogs and package installers

2. **Full-Screen Blocking Overlay (`BlockingActivity`)**
   - Configured with `singleInstance`, `excludeFromRecents`, `showWhenLocked`, and `turnScreenOn`.
   - Displays real-time circular animated countdown.
   - Overrides back-button press to navigate safely to the Android home screen rather than falling back into the blocked app.
   - Motivational focus copy: *"Stay focused. Your apps unlock when your session ends."*

3. **Persistent Session & Reboot Recovery (`BootReceiver` + Room)**
   - Sessions are bound to actual Unix millisecond timestamps (`startTimeMs`, `plannedEndTimeMs`), never volatile in-memory timers.
   - Survives process death, low memory kills, and device reboots (`RECEIVE_BOOT_COMPLETED`, `LOCKED_BOOT_COMPLETED`, `QUICKBOOT_POWERON`).
   - If the device was powered off during the session, `BootReceiver` accurately detects whether the session is still active or expired, records completed minutes, and awards tower level progress accordingly.

4. **Focus Tower Gamification (`TowerScreen`)**
   - Dynamic Jetpack Compose Canvas rendering a multi-story illuminated skyscraper.
   - Each completed focus session unlocks and lights up a new floor with amber and cyan architectural windows.
   - Interrupted sessions do not advance tower level.

5. **Emergency Unlock Protection**
   - Disabled by default for maximum discipline.
   - When enabled in Settings, aborting requires typing `"UNLOCK"` into a confirmation modal and marks the session as `INTERRUPTED` in Room history.

---

## How to Build the APK

### Prerequisites
- Android Studio Ladybug (2024.2.1+) or command line Android SDK
- JDK 17 or higher
- Android SDK Platform 35 and Build-Tools 35.0.0

### Step 1: Clone or Open Project
Open the root directory in Android Studio, or navigate to it in your terminal.

### Step 2: Build Debug APK via Gradle
```bash
# Grant execution permissions (macOS/Linux)
chmod +x gradlew

# Assemble debug APK
./gradlew assembleDebug
```
On Windows:
```cmd
gradlew.bat assembleDebug
```

The compiled APK will be located at:
```
app/build/outputs/apk/debug/app-debug.apk
```

---

## How to Install the APK

### Using ADB
Ensure USB Debugging is enabled on your Android device (Settings → Developer Options → USB Debugging):
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Direct Install on Device
Copy `app-debug.apk` to your phone's internal storage and tap it to install via your file manager (enable "Install unknown apps" if prompted).

---

## How to Enable Accessibility Permission

Because Android restricts accessibility services to prevent abuse:
1. Open the **FocusLock** app.
2. Tap the **"Enable in Settings"** button on the home screen banner (or go to **Settings → System Permissions → Accessibility Blocker Service**).
3. In Android Settings, locate **"FocusLock Session Blocker"** (under *Downloaded apps* or *Accessibility*).
4. Toggle the switch to **ON** and accept the system confirmation prompt.
5. Return to FocusLock — the banner will turn green: **"Accessibility Blocker Active"**.

---

## How to Select Allowed Applications (Suitcase)

1. On the FocusLock home dashboard, tap the **"Allowed Apps (Suitcase)"** card.
2. FocusLock scans all launchable applications installed on your phone.
3. Use the search bar or scroll the list to select essential communication or productivity apps (e.g., Phone, Settings, Google Maps, WhatsApp, Slack).
4. Toggled apps are saved instantly into persistent storage.
5. *Note: Allowed apps cannot be edited while a focus lock session is active.*

---

## How to Start a 3-Hour Focus Session

1. On the home dashboard, scroll the horizontal duration pill selector to the **"180 m"** preset (or tap **"Custom..."** and enter `180`).
2. Verify your Allowed Apps list.
3. Tap **"START FOCUS SESSION"**.
4. The screen locks into focus mode. A persistent notification appears showing the live countdown.
5. Try opening an unallowed application (e.g., Instagram, YouTube, Games) — FocusLock immediately intercepts the launch and displays the full-screen blocking screen!

---

## How to Test Reboot Recovery

1. Start any focus session (e.g., 25 or 45 minutes).
2. Note the remaining time.
3. Power off or restart your phone (`adb reboot`).
4. Once the phone boots back up and unlocks:
   - Notice that the FocusLock persistent notification automatically resumes.
   - Launch FocusLock: the countdown displays the exact remaining time calculated against the original `plannedEndTimeMs`.
   - The Accessibility Service continues blocking unauthorized apps without resetting the session.

---

## Known Android Restrictions & Limitations

1. **Restricted Settings (Android 13+)**:
   - When sideloading an APK via ADB or file manager on Android 13+, Android may grey out Accessibility with "Restricted setting".
   - *Fix*: Go to **Settings → Apps → FocusLock → tap three dots in top-right → "Allow restricted settings"**, then authenticate with your fingerprint/PIN before enabling Accessibility.
2. **OEM Aggressive Battery Optimization**:
   - Brands like Xiaomi (MIUI), Huawei, Samsung, and OnePlus may kill background processes.
   - *Fix*: Exclude FocusLock from battery optimization (Settings → Battery → FocusLock → Unrestricted).
3. **Emergency Phone Calls**:
   - FocusLock's default allowed set includes standard dialer packages (`com.android.dialer`, `com.google.android.dialer`, `com.android.phone`) so emergency calling is always preserved.
