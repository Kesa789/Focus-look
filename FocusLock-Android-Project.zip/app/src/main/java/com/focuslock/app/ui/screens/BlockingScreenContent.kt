package com.focuslock.app.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focuslock.app.ui.components.CircularTimer
import com.focuslock.app.ui.components.EmergencyUnlockDialog
import com.focuslock.app.ui.theme.AmberGlow
import com.focuslock.app.ui.theme.AmberPrimary
import com.focuslock.app.ui.theme.DangerRed
import com.focuslock.app.ui.theme.DarkCardBorder
import com.focuslock.app.ui.theme.DarkSurface
import com.focuslock.app.ui.theme.DarkSurfaceVariant
import com.focuslock.app.ui.theme.PureBlack
import com.focuslock.app.ui.theme.TextMuted
import com.focuslock.app.ui.theme.TextPrimary
import com.focuslock.app.ui.theme.TextSecondary

@Composable
fun BlockingScreenContent(
    blockedAppName: String,
    remainingMillis: Long,
    totalDurationMillis: Long,
    isEmergencyUnlockEnabled: Boolean,
    onReturnToHome: () -> Unit,
    onOpenAllowedApps: () -> Unit,
    onEmergencyUnlock: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showEmergencyUnlockDialog by remember { mutableStateOf(false) }

    // Pulsing subtle glow animation around lock badge
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Glowing Lock Icon
        Box(
            modifier = Modifier
                .scale(pulseScale)
                .size(76.dp)
                .clip(CircleShape)
                .background(AmberGlow)
                .border(2.dp, AmberPrimary, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Locked",
                tint = AmberPrimary,
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "FOCUS SESSION ACTIVE",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp,
            color = AmberPrimary
        )

        Spacer(modifier = Modifier.height(6.dp))

        if (blockedAppName.isNotBlank()) {
            Text(
                text = "$blockedAppName is locked",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Animated Circular Timer with exact remaining time
        CircularTimer(
            remainingMillis = remainingMillis,
            totalDurationMillis = totalDurationMillis,
            isSessionActive = true,
            size = 230.dp,
            strokeWidth = 12.dp
        )

        Spacer(modifier = Modifier.height(28.dp))

        // Core motivational message
        Text(
            text = "Stay focused. Your apps unlock when your session ends.",
            fontSize = 15.sp,
            color = TextSecondary,
            textAlign = TextAlign.Center,
            lineHeight = 22.sp,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(36.dp))

        // Navigation Actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onOpenAllowedApps,
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = DarkSurface,
                    contentColor = TextPrimary
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Work,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = AmberPrimary
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Allowed Apps", fontSize = 13.sp)
            }

            Button(
                onClick = onReturnToHome,
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AmberPrimary,
                    contentColor = PureBlack
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Home,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Home", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (isEmergencyUnlockEnabled) {
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "Emergency Unlock",
                color = DangerRed,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clickable { showEmergencyUnlockDialog = true }
                    .padding(8.dp)
            )
        }
    }

    if (showEmergencyUnlockDialog) {
        EmergencyUnlockDialog(
            onDismiss = { showEmergencyUnlockDialog = false },
            onConfirmUnlock = {
                showEmergencyUnlockDialog = false
                onEmergencyUnlock()
            }
        )
    }
}
