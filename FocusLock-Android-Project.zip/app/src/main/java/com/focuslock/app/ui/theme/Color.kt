package com.focuslock.app.ui.theme

import androidx.compose.ui.graphics.Color

// Premium dark aesthetic inspired by Blockit
val PureBlack = Color(0xFF090A0D)
val DarkSurface = Color(0xFF12141A)
val DarkSurfaceVariant = Color(0xFF1B1D25)
val DarkCardBorder = Color(0xFF262835)

val AmberPrimary = Color(0xFFFF9F1C)
val AmberSecondary = Color(0xFFE08A12)
val AmberGlow = Color(0x33FF9F1C)

val CyanAccent = Color(0xFF2EC4B6)
val CyanGlow = Color(0x332EC4B6)

val TextPrimary = Color(0xFFF6F7FB)
val TextSecondary = Color(0xFF8E91A5)
val TextMuted = Color(0xFF5A5C70)

val DangerRed = Color(0xFFE71D36)
val DangerRedDim = Color(0x2CE71D36)
val SuccessGreen = Color(0xFF2EC4B6)
