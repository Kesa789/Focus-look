package com.focuslock.app.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.focuslock.app.FocusLockApplication
import com.focuslock.app.MainActivity
import com.focuslock.app.R
import com.focuslock.app.data.FocusDatabase
import com.focuslock.app.data.PreferencesManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

class FocusForegroundService : Service() {

    private lateinit var preferencesManager: PreferencesManager
    private lateinit var database: FocusDatabase
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var countdownJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        preferencesManager = PreferencesManager(this)
        database = FocusDatabase.getInstance(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!preferencesManager.isSessionActive()) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildOngoingNotification("Focusing..."))
        startCountdownTicker()

        return START_STICKY
    }

    private fun startCountdownTicker() {
        countdownJob?.cancel()
        countdownJob = serviceScope.launch {
            while (isActive) {
                val endMs = preferencesManager.getSessionEndMs()
                val now = System.currentTimeMillis()
                val diffMs = endMs - now

                if (diffMs <= 0) {
                    onSessionCompleted()
                    break
                }

                val formatted = formatRemainingTime(diffMs)
                updateNotification(formatted)
                delay(1000L)
            }
        }
    }

    private fun onSessionCompleted() {
        serviceScope.launch(Dispatchers.IO) {
            val sessionId = preferencesManager.getActiveSessionId()
            val session = if (sessionId > 0) database.sessionDao().getSessionById(sessionId) else null

            if (session != null && !session.isCompleted) {
                val updated = session.copy(
                    isCompleted = true,
                    actualEndTimeMs = System.currentTimeMillis(),
                    actualDurationMinutes = session.plannedDurationMinutes,
                    towerLevelAwarded = 1
                )
                database.sessionDao().updateSession(updated)
            }

            preferencesManager.incrementTowerLevel()
            preferencesManager.endSession()

            showCompletionNotification()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun buildOngoingNotification(remainingText: String): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, FocusLockApplication.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText("Remaining: $remainingText • Stay locked in")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .build()
    }

    private fun updateNotification(remainingText: String) {
        val notification = buildOngoingNotification(remainingText)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        manager.notify(NOTIFICATION_ID, notification)
    }

    private fun showCompletionNotification() {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            1,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, FocusLockApplication.CHANNEL_ALERT_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(getString(R.string.notification_complete_title))
            .setContentText(getString(R.string.notification_complete_desc))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        manager.notify(COMPLETION_NOTIFICATION_ID, notification)
    }

    private fun formatRemainingTime(millis: Long): String {
        val totalSeconds = (millis / 1000).coerceAtLeast(0)
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60

        return if (hours > 0) {
            String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        countdownJob?.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val NOTIFICATION_ID = 1001
        const val COMPLETION_NOTIFICATION_ID = 1002

        fun startService(context: Context) {
            val intent = Intent(context, FocusForegroundService::class.java)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, FocusForegroundService::class.java)
            context.stopService(intent)
        }
    }
}
