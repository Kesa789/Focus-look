package com.focuslock.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.focuslock.app.service.FocusForegroundService

class SessionAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Log.i("SessionAlarmReceiver", "Session duration alarm elapsed, invoking foreground service check")
        FocusForegroundService.startService(context)
    }
}
