package com.focuslock.app.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Discovers launchable applications installed on the device and manages whitelist preferences.
 */
class AppsRepository(
    private val context: Context,
    private val preferencesManager: PreferencesManager
) {

    suspend fun getInstalledApps(): List<AppInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
        val allowedSet = preferencesManager.getAllowedPackages()
        val ourPackage = context.packageName

        val apps = mutableListOf<AppInfo>()
        val seenPackages = mutableSetOf<String>()

        for (resolveInfo in resolveInfos) {
            val pkg = resolveInfo.activityInfo.packageName
            if (pkg == ourPackage || seenPackages.contains(pkg)) {
                continue
            }
            seenPackages.add(pkg)

            try {
                val appName = resolveInfo.loadLabel(pm).toString()
                val icon = resolveInfo.loadIcon(pm)
                val appInfo = pm.getApplicationInfo(pkg, 0)
                val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0

                apps.add(
                    AppInfo(
                        packageName = pkg,
                        appName = appName,
                        icon = icon,
                        isSystemApp = isSystem,
                        isAllowed = allowedSet.contains(pkg)
                    )
                )
            } catch (e: Exception) {
                // Ignore missing package or resolution errors
            }
        }

        apps.sortedWith(compareBy({ !it.isAllowed }, { it.appName.lowercase() }))
    }

    fun toggleAppAllowed(packageName: String, isAllowed: Boolean) {
        if (isAllowed) {
            preferencesManager.addAllowedPackage(packageName)
        } else {
            preferencesManager.removeAllowedPackage(packageName)
        }
    }

    fun setAllAllowed(packageNames: Set<String>) {
        preferencesManager.setAllowedPackages(packageNames)
    }
}
