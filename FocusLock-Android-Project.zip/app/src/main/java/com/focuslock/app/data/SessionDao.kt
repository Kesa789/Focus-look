package com.focuslock.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SessionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: SessionEntity): Long

    @Update
    suspend fun updateSession(session: SessionEntity)

    @Query("SELECT * FROM focus_sessions WHERE id = :sessionId LIMIT 1")
    suspend fun getSessionById(sessionId: Long): SessionEntity?

    @Query("SELECT * FROM focus_sessions ORDER BY startTimeMs DESC")
    fun getAllSessions(): Flow<List<SessionEntity>>

    @Query("SELECT * FROM focus_sessions WHERE isCompleted = 0 AND isInterrupted = 0 AND plannedEndTimeMs > :currentTimeMs ORDER BY startTimeMs DESC LIMIT 1")
    suspend fun getActiveSession(currentTimeMs: Long): SessionEntity?

    @Query("SELECT COUNT(*) FROM focus_sessions WHERE isCompleted = 1")
    fun getCompletedSessionCount(): Flow<Int>

    @Query("SELECT SUM(actualDurationMinutes) FROM focus_sessions WHERE startTimeMs >= :dayStartMs")
    fun getTodayFocusMinutes(dayStartMs: Long): Flow<Int?>

    @Query("SELECT COUNT(*) FROM focus_sessions WHERE isCompleted = 1")
    suspend fun getCompletedSessionCountImmediate(): Int

    @Query("SELECT * FROM focus_sessions WHERE startTimeMs >= :sinceMs ORDER BY startTimeMs ASC")
    fun getSessionsSince(sinceMs: Long): Flow<List<SessionEntity>>
}
