package com.focuslock.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focuslock.app.ui.theme.AmberGlow
import com.focuslock.app.ui.theme.AmberPrimary
import com.focuslock.app.ui.theme.DarkCardBorder
import com.focuslock.app.ui.theme.DarkSurfaceVariant
import com.focuslock.app.ui.theme.PureBlack
import com.focuslock.app.ui.theme.TextMuted
import com.focuslock.app.ui.theme.TextPrimary
import com.focuslock.app.ui.theme.TextSecondary

val PRESET_DURATIONS = listOf(25, 45, 60, 90, 120, 180)

@Composable
fun DurationPicker(
    selectedMinutes: Int,
    enabled: Boolean,
    onDurationSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var showCustomDialog by remember { mutableStateOf(false) }
    val isCustom = !PRESET_DURATIONS.contains(selectedMinutes)
    val scrollState = rememberScrollState()

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PRESET_DURATIONS.forEach { minutes ->
                val isSelected = selectedMinutes == minutes
                DurationPill(
                    label = formatMinutes(minutes),
                    isSelected = isSelected,
                    enabled = enabled,
                    onClick = { onDurationSelected(minutes) }
                )
            }

            DurationPill(
                label = if (isCustom) "$selectedMinutes m" else "Custom...",
                isSelected = isCustom,
                enabled = enabled,
                onClick = { showCustomDialog = true }
            )
        }
    }

    if (showCustomDialog) {
        CustomDurationDialog(
            currentMinutes = selectedMinutes,
            onDismiss = { showCustomDialog = false },
            onConfirm = { minutes ->
                if (minutes in 1..480) {
                    onDurationSelected(minutes)
                }
                showCustomDialog = false
            }
        )
    }
}

@Composable
private fun DurationPill(
    label: String,
    isSelected: Boolean,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(12.dp)
    val backgroundColor = if (isSelected) AmberPrimary else DarkSurfaceVariant
    val textColor = if (isSelected) PureBlack else if (enabled) TextPrimary else TextMuted
    val borderColor = if (isSelected) AmberPrimary else DarkCardBorder

    Box(
        modifier = Modifier
            .clip(shape)
            .border(1.dp, borderColor, shape)
            .background(backgroundColor)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = textColor
        )
    }
}

@Composable
private fun CustomDurationDialog(
    currentMinutes: Int,
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit
) {
    var textValue by remember { mutableStateOf(currentMinutes.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Custom Focus Duration", color = TextPrimary) },
        text = {
            Column {
                Text(
                    "Enter focus duration in minutes (1 - 480 min):",
                    fontSize = 14.sp,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = textValue,
                    onValueChange = { input ->
                        if (input.all { it.isDigit() } && input.length <= 4) {
                            textValue = input
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val minutes = textValue.toIntOrNull() ?: currentMinutes
                    onConfirm(minutes)
                }
            ) {
                Text("Set", color = AmberPrimary, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        },
        containerColor = DarkSurfaceVariant
    )
}

private fun formatMinutes(minutes: Int): String {
    return when {
        minutes < 60 -> "$minutes m"
        minutes % 60 == 0 -> "${minutes / 60} h"
        else -> "${minutes / 60}h ${minutes % 60}m"
    }
}
