package com.focuslock.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focuslock.app.ui.components.CircularTimer
import com.focuslock.app.ui.components.DurationPicker
import com.focuslock.app.ui.components.EmergencyUnlockDialog
import com.focuslock.app.ui.components.PermissionBanner
import com.focuslock.app.ui.theme.AmberGlow
import com.focuslock.app.ui.theme.AmberPrimary
import com.focuslock.app.ui.theme.CyanAccent
import com.focuslock.app.ui.theme.DangerRed
import com.focuslock.app.ui.theme.DarkCardBorder
import com.focuslock.app.ui.theme.DarkSurface
import com.focuslock.app.ui.theme.DarkSurfaceVariant
import com.focuslock.app.ui.theme.PureBlack
import com.focuslock.app.ui.theme.TextMuted
import com.focuslock.app.ui.theme.TextPrimary
import com.focuslock.app.ui.theme.TextSecondary
import com.focuslock.app.viewmodel.FocusViewModel

@Composable
fun HomeScreen(
    viewModel: FocusViewModel,
    onNavigateToAllowedApps: () -> Unit,
    onNavigateToTower: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isSessionActive by viewModel.isSessionActive.collectAsState()
    val remainingMillis by viewModel.remainingMillis.collectAsState()
    val totalDurationMillis by viewModel.totalDurationMillis.collectAsState()
    val selectedDurationMinutes by viewModel.selectedDurationMinutes.collectAsState()
    val isAccessibilityGranted by viewModel.isAccessibilityGranted.collectAsState()
    val allowedPackages by viewModel.allowedPackages.collectAsState()
    val completedCount by viewModel.completedCount.collectAsState()
    val todayFocusMinutes by viewModel.todayFocusMinutes.collectAsState()
    val towerLevel by viewModel.towerLevel.collectAsState()
    val isEmergencyUnlockEnabled by viewModel.isEmergencyUnlockEnabled.collectAsState()

    var showEmergencyUnlockDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PureBlack)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top App Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(AmberPrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "FocusLock",
                        tint = PureBlack,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "FOCUSLOCK",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.2.sp,
                        color = TextPrimary
                    )
                    Text(
                        text = if (isSessionActive) "LOCKED SESSION" else "STANDBY",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        color = if (isSessionActive) AmberPrimary else TextMuted
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = onNavigateToTower) {
                    Icon(
                        imageVector = Icons.Default.Business,
                        contentDescription = "Focus Tower",
                        tint = CyanAccent
                    )
                }
                IconButton(onClick = onNavigateToHistory) {
                    Icon(
                        imageVector = Icons.Default.BarChart,
                        contentDescription = "History",
                        tint = TextSecondary
                    )
                }
                IconButton(onClick = onNavigateToSettings) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Accessibility Permission Notice if not granted
        PermissionBanner(
            isAccessibilityEnabled = isAccessibilityGranted,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Large Circular Countdown Timer
        CircularTimer(
            remainingMillis = remainingMillis,
            totalDurationMillis = totalDurationMillis,
            isSessionActive = isSessionActive,
            modifier = Modifier.padding(vertical = 8.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Duration Selector
        DurationPicker(
            selectedMinutes = selectedDurationMinutes,
            enabled = !isSessionActive,
            onDurationSelected = { viewModel.setDuration(it) }
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Main Action Button (Start Focus / Emergency Unlock)
        if (!isSessionActive) {
            Button(
                onClick = { viewModel.startSession() },
                enabled = isAccessibilityGranted,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AmberPrimary,
                    disabledContainerColor = DarkSurfaceVariant
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = PureBlack,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "START FOCUS SESSION",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = PureBlack,
                    letterSpacing = 0.5.sp
                )
            }
        } else {
            // Locked session controls
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(DarkSurfaceVariant)
                        .border(1.dp, AmberPrimary, RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = AmberPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Focus Lock is Armed & Active",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                if (isEmergencyUnlockEnabled) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Emergency Unlock Available",
                        color = DangerRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .clickable { showEmergencyUnlockDialog = true }
                            .padding(8.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Suitcase / Allowed Apps Quick Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(DarkSurface)
                .border(1.dp, DarkCardBorder, RoundedCornerShape(16.dp))
                .clickable { onNavigateToAllowedApps() }
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(DarkSurfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Work,
                            contentDescription = "Suitcase",
                            tint = AmberPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Allowed Apps (Suitcase)",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${allowedPackages.size} applications whitelisted",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                Text(
                    text = if (isSessionActive) "LOCKED" else "EDIT →",
                    color = if (isSessionActive) TextMuted else AmberPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Stats Row: Total Focus Time Today & Completed Sessions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatCard(
                title = "TODAY'S FOCUS",
                value = "${todayFocusMinutes ?: 0} min",
                subtitle = "Deep work logged",
                modifier = Modifier.weight(1f)
            )

            StatCard(
                title = "COMPLETED",
                value = "$completedCount",
                subtitle = "Tower level $towerLevel",
                modifier = Modifier.weight(1f)
            )
        }
    }

    if (showEmergencyUnlockDialog) {
        EmergencyUnlockDialog(
            onDismiss = { showEmergencyUnlockDialog = false },
            onConfirmUnlock = {
                showEmergencyUnlockDialog = false
                viewModel.emergencyUnlock()
            }
        )
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = modifier
            .clip(shape)
            .background(DarkSurface)
            .border(1.dp, DarkCardBorder, shape)
            .padding(16.dp)
    ) {
        Text(
            text = title,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            color = TextMuted
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = value,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = subtitle,
            fontSize = 11.sp,
            color = TextSecondary
        )
    }
}
