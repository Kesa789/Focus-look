package com.focuslock.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Manages fast in-memory and SharedPreferences persistence for real-time blocking checks.
 * AccessibilityService cannot afford asynchronous disk or database calls during window change events.
 */
class PreferencesManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREF_FILE_NAME, Context.MODE_PRIVATE)

    private val _allowedPackagesFlow = MutableStateFlow(getAllowedPackages())
    val allowedPackagesFlow: StateFlow<Set<String>> = _allowedPackagesFlow.asStateFlow()

    private val _isSessionActiveFlow = MutableStateFlow(isSessionActive())
    val isSessionActiveFlow: StateFlow<Boolean> = _isSessionActiveFlow.asStateFlow()

    fun getAllowedPackages(): Set<String> {
        return prefs.getStringSet(KEY_ALLOWED_PACKAGES, defaultAllowedPackages) ?: defaultAllowedPackages
    }

    fun setAllowedPackages(packages: Set<String>) {
        prefs.edit().putStringSet(KEY_ALLOWED_PACKAGES, packages).apply()
        _allowedPackagesFlow.value = packages
    }

    fun addAllowedPackage(pkg: String) {
        val updated = getAllowedPackages().toMutableSet()
        updated.add(pkg)
        setAllowedPackages(updated)
    }

    fun removeAllowedPackage(pkg: String) {
        val updated = getAllowedPackages().toMutableSet()
        updated.remove(pkg)
        setAllowedPackages(updated)
    }

    fun startSession(sessionId: Long, startTimeMs: Long, endTimeMs: Long, durationMinutes: Int) {
        prefs.edit()
            .putLong(KEY_ACTIVE_SESSION_ID, sessionId)
            .putLong(KEY_SESSION_START_MS, startTimeMs)
            .putLong(KEY_SESSION_END_MS, endTimeMs)
            .putInt(KEY_SESSION_DURATION_MINUTES, durationMinutes)
            .putBoolean(KEY_SESSION_ACTIVE, true)
            .apply()
        _isSessionActiveFlow.value = true
    }

    fun endSession() {
        prefs.edit()
            .putBoolean(KEY_SESSION_ACTIVE, false)
            .putLong(KEY_ACTIVE_SESSION_ID, -1L)
            .putLong(KEY_SESSION_END_MS, 0L)
            .apply()
        _isSessionActiveFlow.value = false
    }

    fun isSessionActive(): Boolean {
        val active = prefs.getBoolean(KEY_SESSION_ACTIVE, false)
        if (!active) return false
        val endMs = prefs.getLong(KEY_SESSION_END_MS, 0L)
        val now = System.currentTimeMillis()
        if (now >= endMs) {
            // Expired
            endSession()
            return false
        }
        return true
    }

    fun getActiveSessionId(): Long = prefs.getLong(KEY_ACTIVE_SESSION_ID, -1L)
    fun getSessionStartMs(): Long = prefs.getLong(KEY_SESSION_START_MS, 0L)
    fun getSessionEndMs(): Long = prefs.getLong(KEY_SESSION_END_MS, 0L)
    fun getSessionDurationMinutes(): Int = prefs.getInt(KEY_SESSION_DURATION_MINUTES, 25)

    fun isEmergencyUnlockEnabled(): Boolean =
        prefs.getBoolean(KEY_EMERGENCY_UNLOCK, false)

    fun setEmergencyUnlockEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_EMERGENCY_UNLOCK, enabled).apply()
    }

    fun getDefaultDuration(): Int = prefs.getInt(KEY_DEFAULT_DURATION, 25)

    fun setDefaultDuration(minutes: Int) {
        prefs.edit().putInt(KEY_DEFAULT_DURATION, minutes).apply()
    }

    fun getTowerLevel(): Int = prefs.getInt(KEY_TOWER_LEVEL, 0)

    fun incrementTowerLevel(): Int {
        val next = getTowerLevel() + 1
        prefs.edit().putInt(KEY_TOWER_LEVEL, next).apply()
        return next
    }

    fun getNotificationsEnabled(): Boolean = prefs.getBoolean(KEY_NOTIFICATIONS_ENABLED, true)

    fun setNotificationsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_NOTIFICATIONS_ENABLED, enabled).apply()
    }

    companion object {
        private const val PREF_FILE_NAME = "focuslock_prefs"
        private const val KEY_ALLOWED_PACKAGES = "key_allowed_packages"
        private const val KEY_SESSION_ACTIVE = "key_session_active"
        private const val KEY_ACTIVE_SESSION_ID = "key_active_session_id"
        private const val KEY_SESSION_START_MS = "key_session_start_ms"
        private const val KEY_SESSION_END_MS = "key_session_end_ms"
        private const val KEY_SESSION_DURATION_MINUTES = "key_session_duration_minutes"
        private const val KEY_EMERGENCY_UNLOCK = "key_emergency_unlock"
        private const val KEY_DEFAULT_DURATION = "key_default_duration"
        private const val KEY_TOWER_LEVEL = "key_tower_level"
        private const val KEY_NOTIFICATIONS_ENABLED = "key_notifications_enabled"

        // Baseline essential system utilities allowed by default if user chooses
        val defaultAllowedPackages = setOf(
            "com.android.dialer",
            "com.google.android.dialer",
            "com.android.phone",
            "com.android.server.telecom",
            "com.android.settings",
            "com.google.android.apps.messaging",
            "com.android.mms"
        )
    }
}
