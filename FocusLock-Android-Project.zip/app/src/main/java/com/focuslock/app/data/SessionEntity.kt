package com.focuslock.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Persisted record of a focus lock session.
 * Tracks exact timestamps to ensure sessions survive app destruction and reboots.
 */
@Entity(tableName = "focus_sessions")
data class SessionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val startTimeMs: Long,
    val plannedEndTimeMs: Long,
    val actualEndTimeMs: Long? = null,
    val plannedDurationMinutes: Int,
    val actualDurationMinutes: Int = 0,
    val isCompleted: Boolean = false,
    val isInterrupted: Boolean = false,
    val allowedPackagesJson: String = "[]",
    val towerLevelAwarded: Int = 0
)
