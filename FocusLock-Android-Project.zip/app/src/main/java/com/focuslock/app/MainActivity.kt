package com.focuslock.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Modifier
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.focuslock.app.ui.screens.AllowedAppsScreen
import com.focuslock.app.ui.screens.HistoryScreen
import com.focuslock.app.ui.screens.HomeScreen
import com.focuslock.app.ui.screens.SettingsScreen
import com.focuslock.app.ui.screens.TowerScreen
import com.focuslock.app.ui.theme.FocusLockTheme
import com.focuslock.app.ui.theme.PureBlack
import com.focuslock.app.viewmodel.FocusViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: FocusViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            FocusLockTheme {
                // Refresh accessibility status and active session upon app resume
                val lifecycleOwner = LocalLifecycleOwner.current
                DisposableEffect(lifecycleOwner) {
                    val observer = LifecycleEventObserver { _, event ->
                        if (event == Lifecycle.Event.ON_RESUME) {
                            viewModel.refreshAccessibilityStatus()
                            viewModel.checkSessionState()
                        }
                    }
                    lifecycleOwner.lifecycle.addObserver(observer)
                    onDispose {
                        lifecycleOwner.lifecycle.removeObserver(observer)
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = PureBlack
                ) {
                    FocusLockAppNavigation(viewModel)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        viewModel.checkSessionState()
    }
}

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object AllowedApps : Screen("allowed_apps")
    object Tower : Screen("tower")
    object History : Screen("history")
    object Settings : Screen("settings")
}

@Composable
fun FocusLockAppNavigation(viewModel: FocusViewModel) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                viewModel = viewModel,
                onNavigateToAllowedApps = { navController.navigate(Screen.AllowedApps.route) },
                onNavigateToTower = { navController.navigate(Screen.Tower.route) },
                onNavigateToHistory = { navController.navigate(Screen.History.route) },
                onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
            )
        }
        composable(Screen.AllowedApps.route) {
            AllowedAppsScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable(Screen.Tower.route) {
            TowerScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable(Screen.History.route) {
            HistoryScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable(Screen.Settings.route) {
            SettingsScreen(
                viewModel = viewModel,
                onNavigateToAllowedApps = { navController.navigate(Screen.AllowedApps.route) },
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
