package com.focuslock.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.focuslock.app.data.AppsRepository
import com.focuslock.app.data.FocusDatabase
import com.focuslock.app.data.PreferencesManager

class FocusLockApplication : Application() {

    lateinit var database: FocusDatabase
        private set
    lateinit var preferencesManager: PreferencesManager
        private set
    lateinit var appsRepository: AppsRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = FocusDatabase.getInstance(this)
        preferencesManager = PreferencesManager(this)
        appsRepository = AppsRepository(this, preferencesManager)

        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }

            val alertChannel = NotificationChannel(
                CHANNEL_ALERT_ID,
                "FocusLock Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts when session starts or ends"
                setShowBadge(true)
            }

            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
            manager.createNotificationChannel(alertChannel)
        }
    }

    companion object {
        const val CHANNEL_ID = "focuslock_session_channel"
        const val CHANNEL_ALERT_ID = "focuslock_alerts_channel"

        lateinit var instance: FocusLockApplication
            private set
    }
}
