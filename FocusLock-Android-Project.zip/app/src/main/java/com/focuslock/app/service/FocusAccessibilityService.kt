package com.focuslock.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.focuslock.app.BlockingActivity
import com.focuslock.app.data.PreferencesManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * FocusAccessibilityService monitors foreground window changes during active lock sessions.
 * If an unauthorized application enters the foreground, it immediately launches the BlockingActivity.
 */
class FocusAccessibilityService : AccessibilityService() {

    private lateinit var preferencesManager: PreferencesManager
    private var lastBlockedPackage: String? = null
    private var lastBlockTimestamp: Long = 0L
    private var defaultLauncherPackage: String? = null

    override fun onCreate() {
        super.onCreate()
        preferencesManager = PreferencesManager(this)
        resolveDefaultLauncher()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        _isServiceRunning.value = true
        Log.d(TAG, "FocusAccessibilityService connected and ready")

        val info = serviceInfo ?: AccessibilityServiceInfo()
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                AccessibilityEvent.TYPE_WINDOWS_CHANGED
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
        info.flags = AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
        info.notificationTimeout = 50
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        // We care primarily about foreground window changes
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            return
        }

        val eventPackage = event.packageName?.toString() ?: return

        // Fast check: Is there an active session right now?
        if (!preferencesManager.isSessionActive()) {
            return
        }

        // Check if the package is exempt from blocking
        if (isPackageExempt(eventPackage)) {
            return
        }

        // Check if this package is in the user's Allowed Apps (Suitcase)
        val allowedPackages = preferencesManager.getAllowedPackages()
        if (allowedPackages.contains(eventPackage)) {
            return
        }

        // Loop protection: avoid re-launching blocking activity repeatedly within 800ms for same package
        val now = SystemClock.elapsedRealtime()
        if (eventPackage == lastBlockedPackage && (now - lastBlockTimestamp) < 800L) {
            return
        }

        lastBlockedPackage = eventPackage
        lastBlockTimestamp = now

        Log.w(TAG, "Blocking unauthorized app: $eventPackage")
        launchBlockingScreen(eventPackage)
    }

    private fun isPackageExempt(packageName: String): Boolean {
        // 1. FocusLock app itself must never be blocked
        if (packageName == applicationContext.packageName) {
            return true
        }

        // 2. Android System UI, Notification shade, Quick Settings
        if (packageName == "com.android.systemui") {
            return true
        }

        // 3. Android permission controller / package installer
        if (packageName == "com.android.permissioncontroller" ||
            packageName == "com.google.android.permissioncontroller" ||
            packageName == "com.android.packageinstaller"
        ) {
            return true
        }

        // 4. Default Home launcher (so users can view desktop or launch allowed apps)
        if (packageName == defaultLauncherPackage) {
            return true
        }

        // 5. Input Method Editors (keyboards)
        if (packageName.contains("inputmethod") || packageName.contains("ime")) {
            return true
        }

        return false
    }

    private fun launchBlockingScreen(targetPackage: String) {
        val appName = try {
            val pm = packageManager
            val appInfo = pm.getApplicationInfo(targetPackage, 0)
            pm.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
            targetPackage
        }

        val blockingIntent = Intent(this, BlockingActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
            putExtra(BlockingActivity.EXTRA_BLOCKED_PACKAGE, targetPackage)
            putExtra(BlockingActivity.EXTRA_BLOCKED_APP_NAME, appName)
        }

        startActivity(blockingIntent)
    }

    private fun resolveDefaultLauncher() {
        try {
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
            }
            val resolveInfo = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            defaultLauncherPackage = resolveInfo?.activityInfo?.packageName
        } catch (e: Exception) {
            defaultLauncherPackage = null
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "FocusAccessibilityService interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        _isServiceRunning.value = false
        Log.d(TAG, "FocusAccessibilityService destroyed")
    }

    companion object {
        private const val TAG = "FocusAccessibility"

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

        fun isAccessibilityServiceEnabled(context: Context): Boolean {
            val serviceName = "${context.packageName}/${FocusAccessibilityService::class.java.canonicalName}"
            val enabledServices = android.provider.Settings.Secure.getString(
                context.contentResolver,
                android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false

            return enabledServices.contains(serviceName)
        }
    }
}
