package com.focuslock.app.data

import android.graphics.drawable.Drawable

/**
 * Model representing an installed application on the user's Android device.
 */
data class AppInfo(
    val packageName: String,
    val appName: String,
    val icon: Drawable? = null,
    val isSystemApp: Boolean = false,
    val isAllowed: Boolean = false
)
