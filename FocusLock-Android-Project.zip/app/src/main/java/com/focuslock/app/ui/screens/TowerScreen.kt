package com.focuslock.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focuslock.app.ui.theme.AmberGlow
import com.focuslock.app.ui.theme.AmberPrimary
import com.focuslock.app.ui.theme.AmberSecondary
import com.focuslock.app.ui.theme.CyanAccent
import com.focuslock.app.ui.theme.DarkCardBorder
import com.focuslock.app.ui.theme.DarkSurface
import com.focuslock.app.ui.theme.DarkSurfaceVariant
import com.focuslock.app.ui.theme.PureBlack
import com.focuslock.app.ui.theme.TextMuted
import com.focuslock.app.ui.theme.TextPrimary
import com.focuslock.app.ui.theme.TextSecondary
import com.focuslock.app.viewmodel.FocusViewModel

@Composable
fun TowerScreen(
    viewModel: FocusViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val completedCount by viewModel.completedCount.collectAsState()
    val towerLevel by viewModel.towerLevel.collectAsState()
    val effectiveLevel = towerLevel.coerceAtLeast(completedCount)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PureBlack)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // App Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onNavigateBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TextPrimary
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "Focus Tower",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Gamified deep work progress",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Level & Altitude Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(DarkSurface)
                .border(1.dp, DarkCardBorder, RoundedCornerShape(16.dp))
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CURRENT TOWER ALTITUDE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Floor $effectiveLevel",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = AmberPrimary
                    )
                    Text(
                        text = "${effectiveLevel * 45} meters of disciplined focus",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }

                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(DarkSurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = "Trophy",
                        tint = AmberPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Tower Graphic Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(340.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(DarkSurface)
                .border(1.dp, DarkCardBorder, RoundedCornerShape(20.dp)),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val canvasWidth = size.width
                val canvasHeight = size.height

                // Draw atmospheric background gradient lines
                val skyBrush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF0F172A), DarkSurface)
                )
                drawRect(brush = skyBrush)

                // Foundation Ground
                val groundY = canvasHeight - 20f
                drawLine(
                    color = DarkCardBorder,
                    start = Offset(20f, groundY),
                    end = Offset(canvasWidth - 20f, groundY),
                    strokeWidth = 4f
                )

                val floorsToRender = (effectiveLevel + 1).coerceIn(1, 12)
                val floorHeight = 22f
                val baseWidth = 140f

                // Draw each tower floor from bottom up
                for (i in 0 until floorsToRender) {
                    val floorWidth = baseWidth - (i * 5f).coerceAtMost(60f)
                    val left = (canvasWidth - floorWidth) / 2
                    val bottom = groundY - (i * (floorHeight + 4f))
                    val top = bottom - floorHeight

                    val isTopFloor = i == floorsToRender - 1
                    val floorColor = if (isTopFloor && effectiveLevel > 0) {
                        AmberPrimary
                    } else if (i < effectiveLevel) {
                        Color(0xFF33384A)
                    } else {
                        Color(0xFF1E212D)
                    }

                    // Floor slab
                    drawRoundRect(
                        color = floorColor,
                        topLeft = Offset(left, top),
                        size = Size(floorWidth, floorHeight),
                        cornerRadius = CornerRadius(4f, 4f)
                    )

                    // Windows / Illuminated lights
                    if (i < effectiveLevel) {
                        val windowWidth = 6f
                        val windowHeight = 10f
                        val windowCount = (floorWidth / 18f).toInt()
                        for (w in 0 until windowCount) {
                            val winX = left + 10f + (w * 16f)
                            if (winX + windowWidth < left + floorWidth - 6f) {
                                drawRect(
                                    color = if (i % 2 == 0) AmberSecondary else CyanAccent,
                                    topLeft = Offset(winX, top + 6f),
                                    size = Size(windowWidth, windowHeight)
                                )
                            }
                        }
                    }
                }

                // Spire on top of tower
                val topY = groundY - (floorsToRender * (floorHeight + 4f))
                val spireX = canvasWidth / 2
                drawLine(
                    color = AmberPrimary,
                    start = Offset(spireX, topY),
                    end = Offset(spireX, (topY - 30f).coerceAtLeast(30f)),
                    strokeWidth = 3f
                )
                drawCircle(
                    color = AmberPrimary,
                    radius = 5f,
                    center = Offset(spireX, (topY - 30f).coerceAtLeast(30f))
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Each completed focus session adds a new floor to your tower. Interrupted sessions do not advance your architectural milestone.",
            fontSize = 12.sp,
            color = TextSecondary,
            textAlign = TextAlign.Center,
            lineHeight = 18.sp,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
    }
}
