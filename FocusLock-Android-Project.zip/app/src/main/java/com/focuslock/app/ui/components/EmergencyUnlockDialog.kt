package com.focuslock.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focuslock.app.ui.theme.DangerRed
import com.focuslock.app.ui.theme.DarkSurfaceVariant
import com.focuslock.app.ui.theme.TextMuted
import com.focuslock.app.ui.theme.TextPrimary
import com.focuslock.app.ui.theme.TextSecondary

@Composable
fun EmergencyUnlockDialog(
    onDismiss: () -> Unit,
    onConfirmUnlock: () -> Unit
) {
    var confirmationPhrase by remember { mutableStateOf("") }
    val requiredPhrase = "UNLOCK"
    val isConfirmed = confirmationPhrase.trim().uppercase() == requiredPhrase

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Emergency Unlock",
                color = DangerRed,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column {
                Text(
                    "Ending this focus session early will mark the session as INTERRUPTED. Your focus tower progress will not advance.",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    "Type \"$requiredPhrase\" to confirm emergency unlock:",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = confirmationPhrase,
                    onValueChange = { confirmationPhrase = it },
                    placeholder = { Text("UNLOCK", color = TextMuted) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirmUnlock,
                enabled = isConfirmed,
                colors = ButtonDefaults.buttonColors(
                    containerColor = DangerRed,
                    disabledContainerColor = DarkSurfaceVariant
                )
            ) {
                Text("Confirm Break Lock", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Stay Focused", color = TextSecondary)
            }
        },
        containerColor = DarkSurfaceVariant,
        shape = RoundedCornerShape(16.dp)
    )
}
