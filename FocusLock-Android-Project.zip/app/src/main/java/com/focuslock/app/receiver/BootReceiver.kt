package com.focuslock.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.focuslock.app.data.FocusDatabase
import com.focuslock.app.data.PreferencesManager
import com.focuslock.app.service.FocusForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Recovers active focus sessions after device reboot or app upgrade.
 * Recalculates remaining session time from actual persistent timestamps.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_LOCKED_BOOT_COMPLETED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED &&
            action != "android.intent.action.QUICKBOOT_POWERON"
        ) {
            return
        }

        Log.i(TAG, "Reboot or upgrade detected with action: $action")
        val prefs = PreferencesManager(context)

        // Check if there was an active session registered before shutdown
        if (!prefs.isSessionActive()) {
            Log.d(TAG, "No active session to restore")
            return
        }

        val endMs = prefs.getSessionEndMs()
        val now = System.currentTimeMillis()

        if (now >= endMs) {
            // Session expired while device was powered off
            Log.i(TAG, "Session expired while device was off, completing session")
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = FocusDatabase.getInstance(context)
                    val sessionId = prefs.getActiveSessionId()
                    if (sessionId > 0) {
                        val session = db.sessionDao().getSessionById(sessionId)
                        if (session != null && !session.isCompleted) {
                            db.sessionDao().updateSession(
                                session.copy(
                                    isCompleted = true,
                                    actualEndTimeMs = endMs,
                                    actualDurationMinutes = session.plannedDurationMinutes,
                                    towerLevelAwarded = 1
                                )
                            )
                        }
                    }
                    prefs.incrementTowerLevel()
                } finally {
                    prefs.endSession()
                    pendingResult.finish()
                }
            }
        } else {
            // Session is still active!
            val remainingMinutes = ((endMs - now) / 60000).toInt()
            Log.i(TAG, "Restoring active session after reboot with $remainingMinutes minutes remaining")

            try {
                FocusForegroundService.startService(context)
            } catch (e: Exception) {
                Log.e(TAG, "Could not start foreground service immediately due to background restrictions", e)
            }
        }
    }

    companion object {
        private const val TAG = "FocusBootReceiver"
    }
}
