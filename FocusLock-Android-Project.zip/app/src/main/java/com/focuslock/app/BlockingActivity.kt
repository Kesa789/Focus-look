package com.focuslock.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.focuslock.app.data.FocusDatabase
import com.focuslock.app.data.PreferencesManager
import com.focuslock.app.service.FocusForegroundService
import com.focuslock.app.ui.screens.BlockingScreenContent
import com.focuslock.app.ui.theme.FocusLockTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Fullscreen blocking activity launched whenever an unauthorized application is focused.
 */
class BlockingActivity : ComponentActivity() {

    private lateinit var preferencesManager: PreferencesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferencesManager = PreferencesManager(this)

        val blockedAppName = intent.getStringExtra(EXTRA_BLOCKED_APP_NAME) ?: "Application"

        setContent {
            FocusLockTheme {
                val startMs = preferencesManager.getSessionStartMs()
                val endMs = preferencesManager.getSessionEndMs()
                val totalDuration = (endMs - startMs).coerceAtLeast(60000L)

                var remainingMillis by remember {
                    mutableLongStateOf((endMs - System.currentTimeMillis()).coerceAtLeast(0L))
                }

                LaunchedEffect(Unit) {
                    while (isActive) {
                        val currentRemaining = preferencesManager.getSessionEndMs() - System.currentTimeMillis()
                        if (currentRemaining <= 0 || !preferencesManager.isSessionActive()) {
                            finish()
                            break
                        }
                        remainingMillis = currentRemaining
                        delay(1000L)
                    }
                }

                BlockingScreenContent(
                    blockedAppName = blockedAppName,
                    remainingMillis = remainingMillis,
                    totalDurationMillis = totalDuration,
                    isEmergencyUnlockEnabled = preferencesManager.isEmergencyUnlockEnabled(),
                    onReturnToHome = {
                        val homeIntent = Intent(this@BlockingActivity, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                        }
                        startActivity(homeIntent)
                        finish()
                    },
                    onOpenAllowedApps = {
                        val homeIntent = Intent(this@BlockingActivity, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                            putExtra("NAVIGATE_TO", "ALLOWED_APPS")
                        }
                        startActivity(homeIntent)
                        finish()
                    },
                    onEmergencyUnlock = {
                        performEmergencyUnlock()
                    }
                )
            }
        }
    }

    private fun performEmergencyUnlock() {
        CoroutineScope(Dispatchers.IO).launch {
            val sessionId = preferencesManager.getActiveSessionId()
            if (sessionId > 0) {
                val db = FocusDatabase.getInstance(this@BlockingActivity)
                val session = db.sessionDao().getSessionById(sessionId)
                if (session != null) {
                    val now = System.currentTimeMillis()
                    val actualMin = ((now - session.startTimeMs) / 60000).toInt()
                    db.sessionDao().updateSession(
                        session.copy(
                            actualEndTimeMs = now,
                            actualDurationMinutes = actualMin,
                            isInterrupted = true,
                            isCompleted = false
                        )
                    )
                }
            }

            preferencesManager.endSession()
            FocusForegroundService.stopService(this@BlockingActivity)
            finish()
        }
    }

    override fun onBackPressed() {
        // Prevent back press from returning to blocked app
        val startMain = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(startMain)
    }

    companion object {
        const val EXTRA_BLOCKED_PACKAGE = "extra_blocked_package"
        const val EXTRA_BLOCKED_APP_NAME = "extra_blocked_app_name"
    }
}
