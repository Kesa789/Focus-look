package com.focuslock.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focuslock.app.ui.components.openAccessibilitySettings
import com.focuslock.app.ui.theme.AmberPrimary
import com.focuslock.app.ui.theme.DangerRed
import com.focuslock.app.ui.theme.DarkCardBorder
import com.focuslock.app.ui.theme.DarkSurface
import com.focuslock.app.ui.theme.DarkSurfaceVariant
import com.focuslock.app.ui.theme.PureBlack
import com.focuslock.app.ui.theme.SuccessGreen
import com.focuslock.app.ui.theme.TextMuted
import com.focuslock.app.ui.theme.TextPrimary
import com.focuslock.app.ui.theme.TextSecondary
import com.focuslock.app.viewmodel.FocusViewModel

@Composable
fun SettingsScreen(
    viewModel: FocusViewModel,
    onNavigateToAllowedApps: () -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isAccessibilityGranted by viewModel.isAccessibilityGranted.collectAsState()
    val isEmergencyUnlockEnabled by viewModel.isEmergencyUnlockEnabled.collectAsState()
    val selectedDurationMinutes by viewModel.selectedDurationMinutes.collectAsState()
    val isSessionActive by viewModel.isSessionActive.collectAsState()

    var showEmergencyConfirmDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PureBlack)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        // App Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onNavigateBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TextPrimary
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Settings",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // System Permissions Section
        SectionHeader("SYSTEM PERMISSIONS")

        SettingsTile(
            title = "Accessibility Blocker Service",
            subtitle = if (isAccessibilityGranted) "Active and enforcing app lock" else "Required to detect foreground apps",
            trailing = {
                Text(
                    text = if (isAccessibilityGranted) "ACTIVE" else "ENABLE",
                    color = if (isAccessibilityGranted) SuccessGreen else AmberPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            onClick = {
                openAccessibilitySettings(context)
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        // App Restrictions Section
        SectionHeader("APP RESTRICTIONS")

        SettingsTile(
            title = "Allowed Apps (Suitcase)",
            subtitle = "Choose applications accessible during focus sessions",
            trailing = {
                Text(
                    text = "CONFIGURE →",
                    color = AmberPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            onClick = onNavigateToAllowedApps
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Security & Lockdown Section
        SectionHeader("SECURITY & LOCKDOWN")

        SettingsTile(
            title = "Emergency Unlock",
            subtitle = if (isEmergencyUnlockEnabled) "Enabled: Type UNLOCK to abort" else "Disabled: Sessions cannot be canceled early",
            trailing = {
                Switch(
                    checked = isEmergencyUnlockEnabled,
                    onCheckedChange = { enable ->
                        if (enable) {
                            showEmergencyConfirmDialog = true
                        } else {
                            viewModel.setEmergencyUnlock(false)
                        }
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = PureBlack,
                        checkedTrackColor = AmberPrimary,
                        uncheckedTrackColor = DarkSurfaceVariant
                    )
                )
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Preferences Section
        SectionHeader("DEFAULT PREFERENCES")

        SettingsTile(
            title = "Default Focus Duration",
            subtitle = "$selectedDurationMinutes minutes planned for next session",
            trailing = {
                Text(
                    text = "$selectedDurationMinutes m",
                    color = AmberPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        )

        SettingsTile(
            title = "Theme",
            subtitle = "True OLED Dark Mode (Inspired by Blockit)",
            trailing = {
                Text(
                    text = "OLED DARK",
                    color = TextMuted,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        )

        Spacer(modifier = Modifier.height(28.dp))

        // App Info
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "FocusLock v1.0.0",
                fontSize = 12.sp,
                color = TextMuted,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = "Kotlin • Jetpack Compose • Accessibility Service",
                fontSize = 11.sp,
                color = TextMuted
            )
        }
    }

    if (showEmergencyConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showEmergencyConfirmDialog = false },
            title = { Text("Enable Emergency Unlock?", color = DangerRed) },
            text = {
                Text(
                    "Enabling Emergency Unlock gives you an option to abort active sessions by typing a confirmation phrase. For strictest discipline, keeping this OFF is recommended.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.setEmergencyUnlock(true)
                        showEmergencyConfirmDialog = false
                    }
                ) {
                    Text("Enable", color = DangerRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEmergencyConfirmDialog = false }) {
                    Text("Keep Strict", color = TextPrimary)
                }
            },
            containerColor = DarkSurfaceVariant
        )
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.2.sp,
        color = TextMuted,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun SettingsTile(
    title: String,
    subtitle: String,
    trailing: @Composable () -> Unit,
    onClick: (() -> Unit)? = null
) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(shape)
            .background(DarkSurface)
            .border(1.dp, DarkCardBorder, shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = TextSecondary
            )
        }
        trailing()
    }
}
