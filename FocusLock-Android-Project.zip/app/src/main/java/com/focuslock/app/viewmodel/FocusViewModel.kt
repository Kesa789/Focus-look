package com.focuslock.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.focuslock.app.FocusLockApplication
import com.focuslock.app.data.AppInfo
import com.focuslock.app.data.SessionEntity
import com.focuslock.app.service.FocusAccessibilityService
import com.focuslock.app.service.FocusForegroundService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Calendar

class FocusViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as FocusLockApplication
    private val database = app.database
    private val preferences = app.preferencesManager
    private val appsRepo = app.appsRepository

    val isSessionActive: StateFlow<Boolean> = preferences.isSessionActiveFlow

    private val _remainingMillis = MutableStateFlow(0L)
    val remainingMillis: StateFlow<Long> = _remainingMillis.asStateFlow()

    private val _totalDurationMillis = MutableStateFlow(25L * 60 * 1000)
    val totalDurationMillis: StateFlow<Long> = _totalDurationMillis.asStateFlow()

    private val _selectedDurationMinutes = MutableStateFlow(preferences.getDefaultDuration())
    val selectedDurationMinutes: StateFlow<Int> = _selectedDurationMinutes.asStateFlow()

    private val _installedApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val installedApps: StateFlow<List<AppInfo>> = _installedApps.asStateFlow()

    val allowedPackages: StateFlow<Set<String>> = preferences.allowedPackagesFlow

    private val _isAccessibilityGranted = MutableStateFlow(false)
    val isAccessibilityGranted: StateFlow<Boolean> = _isAccessibilityGranted.asStateFlow()

    private val _isEmergencyUnlockEnabled = MutableStateFlow(preferences.isEmergencyUnlockEnabled())
    val isEmergencyUnlockEnabled: StateFlow<Boolean> = _isEmergencyUnlockEnabled.asStateFlow()

    private val _towerLevel = MutableStateFlow(preferences.getTowerLevel())
    val towerLevel: StateFlow<Int> = _towerLevel.asStateFlow()

    val allSessions = database.sessionDao().getAllSessions()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val completedCount = database.sessionDao().getCompletedSessionCount()
        .stateIn(viewModelScope, SharingStarted.Lazily, 0)

    val todayFocusMinutes = database.sessionDao().getTodayFocusMinutes(getStartOfTodayMs())
        .stateIn(viewModelScope, SharingStarted.Lazily, 0)

    private var tickerJob: Job? = null

    init {
        checkSessionState()
        refreshAccessibilityStatus()
        loadInstalledApps()
    }

    fun refreshAccessibilityStatus() {
        val granted = FocusAccessibilityService.isAccessibilityServiceEnabled(app)
        _isAccessibilityGranted.value = granted
    }

    fun loadInstalledApps() {
        viewModelScope.launch {
            val apps = appsRepo.getInstalledApps()
            _installedApps.value = apps
        }
    }

    fun setDuration(minutes: Int) {
        if (!preferences.isSessionActive()) {
            _selectedDurationMinutes.value = minutes
            _totalDurationMillis.value = minutes * 60L * 1000L
            _remainingMillis.value = minutes * 60L * 1000L
        }
    }

    fun toggleApp(packageName: String, allowed: Boolean) {
        if (!preferences.isSessionActive()) {
            appsRepo.toggleAppAllowed(packageName, allowed)
            loadInstalledApps()
        }
    }

    fun setEmergencyUnlock(enabled: Boolean) {
        preferences.setEmergencyUnlockEnabled(enabled)
        _isEmergencyUnlockEnabled.value = enabled
    }

    fun checkSessionState() {
        val active = preferences.isSessionActive()
        if (active) {
            val endMs = preferences.getSessionEndMs()
            val startMs = preferences.getSessionStartMs()
            val now = System.currentTimeMillis()
            val diff = (endMs - now).coerceAtLeast(0)

            _totalDurationMillis.value = (endMs - startMs).coerceAtLeast(60000L)
            _remainingMillis.value = diff
            startTicker()
        } else {
            val dur = _selectedDurationMinutes.value
            _totalDurationMillis.value = dur * 60L * 1000L
            _remainingMillis.value = dur * 60L * 1000L
            tickerJob?.cancel()
        }
    }

    fun startSession() {
        if (preferences.isSessionActive()) return

        val durationMin = _selectedDurationMinutes.value
        val startMs = System.currentTimeMillis()
        val endMs = startMs + (durationMin * 60L * 1000L)
        val allowedJson = preferences.getAllowedPackages().joinToString(prefix = "[\"", separator = "\",\"", postfix = "\"]")

        viewModelScope.launch {
            val session = SessionEntity(
                startTimeMs = startMs,
                plannedEndTimeMs = endMs,
                plannedDurationMinutes = durationMin,
                allowedPackagesJson = allowedJson
            )
            val id = database.sessionDao().insertSession(session)
            preferences.startSession(id, startMs, endMs, durationMin)

            _totalDurationMillis.value = durationMin * 60L * 1000L
            _remainingMillis.value = durationMin * 60L * 1000L

            FocusForegroundService.startService(app)
            startTicker()
        }
    }

    fun emergencyUnlock() {
        if (!preferences.isEmergencyUnlockEnabled()) return

        viewModelScope.launch {
            val sessionId = preferences.getActiveSessionId()
            if (sessionId > 0) {
                val session = database.sessionDao().getSessionById(sessionId)
                if (session != null) {
                    val now = System.currentTimeMillis()
                    val actualMin = ((now - session.startTimeMs) / 60000).toInt()
                    val interrupted = session.copy(
                        actualEndTimeMs = now,
                        actualDurationMinutes = actualMin,
                        isInterrupted = true,
                        isCompleted = false
                    )
                    database.sessionDao().updateSession(interrupted)
                }
            }

            preferences.endSession()
            FocusForegroundService.stopService(app)
            checkSessionState()
        }
    }

    private fun startTicker() {
        tickerJob?.cancel()
        tickerJob = viewModelScope.launch {
            while (isActive) {
                val endMs = preferences.getSessionEndMs()
                val now = System.currentTimeMillis()
                val diff = endMs - now

                if (diff <= 0) {
                    _remainingMillis.value = 0L
                    checkSessionState()
                    _towerLevel.value = preferences.getTowerLevel()
                    break
                }

                _remainingMillis.value = diff
                delay(1000L)
            }
        }
    }

    private fun getStartOfTodayMs(): Long {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return calendar.timeInMillis
    }
}
